
import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { Language, translations } from '../translations';
import { ChevronLeft, ChevronRight, Info, Zap, FlaskConical, Heart, ShieldCheck, ShoppingBag } from 'lucide-react';

const BoldText = ({ text }: { text: string }) => {
  const parts = text.split(/(\*\*.*?\*\*)/g);
  return (
    <>
      {parts.map((part, i) => 
        part.startsWith('**') && part.endsWith('**') 
          ? <strong key={i} className="font-bold text-[#db7536]">{part.slice(2, -2)}</strong> 
          : part
      )}
    </>
  );
};

export const Solution = ({ lang }: { lang: Language }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const t = translations.solution;
  const heroT = translations.hero;

  const cards = [
    {
      main: (t as any).card1.main[lang],
      title: (t as any).card1.title[lang],
      desc: (t as any).card1.desc[lang],
      icon: <Info size={40} className="text-[#db7536]" />,
      bg: 'bg-white',
      accent: 'border-[#db7536]'
    },
    {
      main: (t as any).card2.main[lang],
      title: (t as any).card2.title[lang],
      desc: (t as any).card2.desc[lang],
      icon: <Heart size={40} className="text-[#db7536]" />,
      bg: 'bg-white',
      accent: 'border-[#db7536]'
    },
    {
      main: (t as any).card3.main[lang],
      title: (t as any).card3.title[lang],
      desc: (t as any).card3.desc[lang],
      icon: <FlaskConical size={40} className="text-[#db7536]" />,
      bg: 'bg-white',
      accent: 'border-[#db7536]'
    },
    {
      main: (t as any).card4.main[lang],
      title: (t as any).card4.title[lang],
      desc: (t as any).card4.desc[lang],
      icon: <ShieldCheck size={40} className="text-[#db7536]" />,
      bg: 'bg-white',
      accent: 'border-[#db7536]'
    },
    {
      main: (t as any).card5.main[lang],
      title: (t as any).card5.title[lang],
      desc: (t as any).card5.desc[lang],
      icon: <Zap size={40} className="text-[#db7536]" />,
      bg: 'bg-white',
      accent: 'border-[#db7536]'
    }
  ];

  const next = () => setCurrentIndex((prev) => (prev + 1) % cards.length);
  const prev = () => setCurrentIndex((prev) => (prev - 1 + cards.length) % cards.length);

  return (
    <section id="solution" className="py-24 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 text-center md:text-left">
          <div>
            <h2 className="text-sm font-bold text-[#db7536] uppercase tracking-[0.3em] mb-4">{t.title[lang]}</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-gray-900 tracking-tight">Science Based Innovation</h3>
          </div>
          <div className="flex gap-4 justify-center">
            <button 
              onClick={prev} 
              className="p-4 rounded-full border border-gray-200 hover:border-[#db7536] hover:text-[#db7536] transition-all bg-white shadow-sm group active:scale-95"
              aria-label="Previous card"
            >
              <ChevronLeft className="group-hover:-translate-x-0.5 transition-transform" />
            </button>
            <button 
              onClick={next} 
              className="p-4 rounded-full border border-gray-200 hover:border-[#db7536] hover:text-[#db7536] transition-all bg-white shadow-sm group active:scale-95"
              aria-label="Next card"
            >
              <ChevronRight className="group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>

        <div className="relative h-[600px] sm:h-[450px] md:h-[400px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className={`absolute inset-0 flex flex-col md:flex-row items-center gap-8 md:gap-16 p-8 md:p-20 rounded-[48px] border-b-8 ${cards[currentIndex].accent} ${cards[currentIndex].bg} shadow-2xl shadow-orange-100/50`}
            >
              <div className="w-24 h-24 rounded-[32px] bg-orange-50 flex items-center justify-center shrink-0 shadow-inner">
                {cards[currentIndex].icon}
              </div>
              <div className="flex-1">
                <span className="text-[#db7536] text-xs font-black uppercase tracking-widest mb-2 block">
                  {cards[currentIndex].main}
                </span>
                <h4 className="text-2xl md:text-4xl font-bold mb-6 text-gray-900 leading-tight">
                  {cards[currentIndex].title}
                </h4>
                <p className="text-lg md:text-xl text-gray-500 leading-relaxed max-w-3xl">
                  <BoldText text={cards[currentIndex].desc} />
                </p>
                
                {currentIndex === cards.length - 1 && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mt-10"
                  >
                    <a 
                      href="#products"
                      className="inline-flex items-center gap-3 px-8 py-4 bg-[#db7536] text-white rounded-2xl font-bold hover:bg-[#c6652e] transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-orange-200"
                    >
                      <ShoppingBag size={20} />
                      {heroT.ctaProducts[lang]}
                    </a>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
        
        {/* Indicators */}
        <div className="flex justify-center mt-12 gap-3">
          {cards.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-2.5 rounded-full transition-all duration-500 ${currentIndex === idx ? 'w-12 bg-[#db7536]' : 'w-2.5 bg-gray-200 hover:bg-gray-300'}`}
              aria-label={`Go to card ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
