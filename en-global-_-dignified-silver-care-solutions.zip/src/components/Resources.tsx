
import { Language, translations } from '../translations';
import { Download, FileText, ChevronDown } from 'lucide-react';
import { motion } from 'motion/react';

export const Resources = ({ lang }: { lang: Language }) => {
  const t = translations.resources;
  
  const catalogIds = {
    EN: '1s5d2EAn9nSGp-HrWWpmpGJ9g5iKcXsOP',
    JP: '1fdekiVX721lWbffBsD7MtkMMo6HKs9J8'
  };

  const previewUrl = `https://drive.google.com/file/d/${catalogIds[lang]}/preview`;
  const downloadUrl = `https://drive.google.com/uc?export=download&id=${catalogIds[lang]}`;

  return (
    <section id="resources" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h2 className="text-sm font-bold text-[#db7536] uppercase tracking-widest mb-4">{t.title[lang]}</h2>
          <h3 className="text-4xl font-bold mb-6">{t.subtitle[lang]}</h3>
          <div className="flex items-center justify-center gap-2 text-gray-400 text-sm animate-bounce">
            <ChevronDown size={16} />
            {t.viewCatalog[lang]}
          </div>
        </motion.div>

        <div className="relative w-full max-w-5xl mx-auto bg-gray-50 rounded-[32px] overflow-hidden border border-gray-100 shadow-2xl mb-10 min-h-[850px]">
          <iframe
            src={previewUrl}
            className="w-full h-[850px] border-none"
            allow="autoplay"
          ></iframe>
        </div>

        <motion.div
           initial={{ opacity: 0, scale: 0.95 }}
           whileInView={{ opacity: 1, scale: 1 }}
           transition={{ delay: 0.2 }}
        >
          <a
            href={downloadUrl}
            className="inline-flex items-center gap-3 px-10 py-5 bg-[#db7536] text-white rounded-full font-bold shadow-lg shadow-[#db7536]/20 hover:bg-[#c6652e] hover:scale-105 active:scale-95 transition-all text-lg group"
          >
            <Download size={22} className="group-hover:translate-y-0.5 transition-transform" />
            {t.downloadBtn[lang]}
          </a>
          <p className="mt-4 text-xs text-gray-400 font-medium">
            {lang === 'EN' ? 'PDF (High Resolution) • Direct Download' : 'PDF (高解像度) • 直接ダウンロード'}
          </p>
        </motion.div>
      </div>
    </section>
  );
};
