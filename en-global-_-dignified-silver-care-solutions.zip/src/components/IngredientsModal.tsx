
import { motion, AnimatePresence } from 'motion/react';
import { X, Beaker, Leaf, Droplets, ShieldCheck } from 'lucide-react';
import { useEffect } from 'react';

interface IngredientsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ingredientGroups = [
  {
    title: 'Base & Tech',
    icon: <Beaker size={20} />,
    color: 'bg-blue-50 text-blue-600 border-blue-100',
    ingredients: [
      'Water', 'Butylene Glycol', 'Hydroxyacetophenone', 
      'Sodium Bicarbonate', 'Laurylpyridinium Chloride', 'Disodium EDTA'
    ]
  },
  {
    title: 'Natural Extracts (Soothing & Protection)',
    icon: <Leaf size={20} />,
    color: 'bg-green-50 text-green-600 border-green-100',
    ingredients: [
      'Chamomile Flower', 'White Willow Bark', 'Aloe Vera Leaf', 
      'Propolis', 'Grapefruit Seed', 'Lycium Chinense Root'
    ]
  },
  {
    title: 'Moisturizer',
    icon: <Droplets size={20} />,
    color: 'bg-cyan-50 text-cyan-600 border-cyan-100',
    ingredients: [
      'Sodium Hyaluronate'
    ]
  }
];

export const IngredientsModal = ({ isOpen, onClose }: IngredientsModalProps) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 30 }}
            className="relative bg-white rounded-[32px] shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden z-20 flex flex-col"
          >
            {/* Header */}
            <div className="p-8 border-b border-gray-100 flex items-start justify-between bg-gray-50/50">
              <div>
                <div className="flex items-center gap-2 text-green-600 font-bold text-xs uppercase tracking-widest mb-3">
                  <ShieldCheck size={14} /> EWG Green Grade Standards
                </div>
                <h2 className="text-3xl font-bold text-[#333]">FULL INGREDIENTS (EN)</h2>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-white rounded-full text-gray-400 hover:text-[#db7536] transition-all shadow-sm border border-gray-100"
              >
                <X size={24} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-8 space-y-8">
              {ingredientGroups.map((group, i) => (
                <div key={i} className="animate-in fade-in slide-in-from-bottom duration-500" style={{ animationDelay: `${i * 100}ms` }}>
                  <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full border ${group.color} text-[10px] font-bold uppercase tracking-widest mb-4`}>
                    {group.icon}
                    {group.title}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {group.ingredients.map((ing, j) => (
                      <div key={j} className="flex items-center gap-3 p-3 rounded-xl bg-white border border-gray-100 hover:border-green-200 hover:bg-green-50/30 transition-all group">
                        <div className="w-2 h-2 rounded-full bg-green-200 group-hover:bg-green-400 transition-colors" />
                        <span className="text-sm font-medium text-gray-700">{ing}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="p-6 bg-gray-50 border-t border-gray-100 text-center">
              <p className="text-xs text-gray-400">
                Our formula is strictly developed focusing on skin safety and elderly hygiene.
              </p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
