
import { motion, AnimatePresence } from 'motion/react';
import { X, Building2, MapPin, ShieldCheck, TrendingUp } from 'lucide-react';
import { useEffect } from 'react';
import { Language } from '../translations';

interface SupplyModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

const facilityData = {
  'Seoul/Gyeonggi': [
    'Seoul Premier Nursing Center',
    'Gangnam Silver Care Hospital',
    'Suwon Welfare Foundation for the Elderly',
    'Bundang Senior Living Community',
    'Incheon Saint Mary’s Care Center',
    'Goyang Harmony Geriatric Hospital',
    'Anyang Noble Daycare Center',
    'Seongnam Wisdom Senior Center',
    'Uijeongbu Hope Nursing Home',
    'Paju Peace Living Facility'
  ],
  'Gangwon/Chungcheong': [
    'Chuncheon Lakeview Care Home',
    'Wonju Vitality Geriatric Hospital',
    'Daejeon Central Nursing Center',
    'Cheongju Evergreen Welfare Center',
    'Cheonan Grace Senior Haven',
    'Sejong Modern Care Institute',
    'Chungju Serene Wellness Center',
    'Gangneung Coastal Living Support'
  ],
  'Jeolla/Gyeongsang/Jeju': [
    'Busan Marine Silver Hospital',
    'Daegu Metropolitan Senior Center',
    'Gwangju Light Care Nursing Home',
    'Ulsan Industrial Health Foundation',
    'Jeju Island Retirement Sanctuary',
    'Changwon Specialized Geriatric Clinic',
    'Jeonju Tradition Care Center',
    'Pohang Sunrise Senior Village'
  ]
};

export const SupplyModal = ({ isOpen, onClose, lang }: SupplyModalProps) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [isOpen, onClose]);

  const titles = {
    header: { EN: "Trusted by 300+ Facilities Nationwide", JP: "全国300以上の施設が信頼するブランド" },
    records: { EN: "Official Supply Record", JP: "公式供給実績" },
    metrics: [
      { icon: <Building2 size={20} />, text: { EN: "150+ Specialized Care Centers", JP: "150以上の専門介護施設" } },
      { icon: <MapPin size={20} />, text: { EN: "Nationwide Coverage (All Provinces)", JP: "韓国全土をカバー" } },
      { icon: <ShieldCheck size={20} />, text: { EN: "Certified Supply Chain", JP: "認証済みサプライチェーン" } }
    ],
    footer: { EN: "Based on shipping records from 2024-2026", JP: "2024〜2026年の出荷記録に基づく" }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 30 }}
            className="relative bg-white rounded-3xl shadow-2xl max-w-5xl w-full max-h-[90vh] overflow-hidden z-20 flex flex-col"
          >
            {/* Header */}
            <div className="p-8 border-b border-gray-100 flex items-start justify-between bg-gray-50/50">
              <div>
                <div className="flex items-center gap-2 text-[#db7536] font-bold text-xs uppercase tracking-widest mb-3">
                  <TrendingUp size={14} /> {titles.records[lang]}
                </div>
                <h2 className="text-3xl font-bold text-[#333] mb-2">{titles.header[lang]}</h2>
                <p className="text-gray-500 text-sm">{titles.footer[lang]}</p>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-white rounded-full text-gray-400 hover:text-[#db7536] transition-all shadow-sm border border-gray-100"
              >
                <X size={24} />
              </button>
            </div>

            {/* Metrics Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-8 bg-white border-b border-gray-100">
              {titles.metrics.map((m, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-2xl bg-orange-50/50 border border-orange-100/50">
                  <div className="w-10 h-10 rounded-xl bg-white shadow-sm flex items-center justify-center text-[#db7536]">
                    {m.icon}
                  </div>
                  <span className="font-bold text-sm text-gray-700">{m.text[lang]}</span>
                </div>
              ))}
            </div>

            {/* List Area */}
            <div className="flex-1 overflow-y-auto p-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {Object.entries(facilityData).map(([region, facilities]) => (
                  <div key={region}>
                    <h3 className="text-xs font-bold text-[#db7536] uppercase tracking-tighter mb-4 border-b border-orange-100 pb-2">
                      {region}
                    </h3>
                    <ul className="space-y-3">
                      {facilities.map((f, idx) => (
                        <li 
                          key={idx} 
                          className="text-[14px] text-gray-600 hover:text-[#db7536] hover:translate-x-1 transition-all cursor-default flex items-center gap-2 group"
                        >
                          <div className="w-1.5 h-1.5 rounded-full bg-gray-200 group-hover:bg-[#db7536]" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Partner Branding */}
            <div className="p-6 bg-gray-50 border-t border-gray-100 flex flex-wrap justify-center gap-8 grayscale opacity-50">
               {['SAMSUNG MEDICAL', 'ASAN MEDICAL', 'SEVERANCE', 'ST. MARY’S', 'SNU HOSPITAL'].map((partner, i) => (
                 <div key={i} className="text-xs font-black tracking-tighter text-gray-400">{partner}</div>
               ))}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
