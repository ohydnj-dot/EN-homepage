
import { motion } from 'motion/react';
import { Language, translations } from '../translations';
import { Package, Droplets, Wind, Info } from 'lucide-react';

export const Products = ({ lang }: { lang: Language }) => {
  const t = translations.products;

  const productList = [
    {
      id: 'wipes',
      icon: <Package size={24} />,
      image: "https://www.enbcs.kr/theme/enbcs/img/business/new_eq_2.jpg",
      content: t.wipes,
      badge: { EN: "Export-Spec", JP: "輸出仕様" }
    },
    {
      id: 'spray',
      icon: <Wind size={24} />,
      image: "https://postfiles.pstatic.net/MjAyNjA1MTBfMTg5/MDAxNzc4NDI0MzM2MTQ1.kzVufrI2_fqphlqTkteOUB8S9emSGGKEuO2_59vPYTQg.6sEIVdKRDcgUcZO_nRQR1-mqjZ15mx1h0vPvSLm_HqYg.PNG/127.png?type=w966",
      content: t.spray,
    },
    {
      id: 'bodywash',
      icon: <Droplets size={24} />,
      image: "https://postfiles.pstatic.net/MjAyNjA1MTBfMTUx/MDAxNzc4NDI0MzM2MTM3.Pf3C57z4S9RbH8tP6BnhmHQ5DA9ZnEtXG_1-IHLBEmUg.4aKKKaiZi9CsgV7b8JU9SFq_Nu_O69O8PNxG1i7YhFkg.PNG/126.png?type=w966",
      content: t.bodywash,
    }
  ];

  return (
    <section id="products" className="py-24 -mt-20 relative z-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-sm font-bold text-[#db7536] uppercase tracking-[0.3em] mb-4">Professional Selection</h2>
          <h3 className="text-5xl font-bold tracking-tight">{t.title[lang]}</h3>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {productList.map((product) => (
            <motion.div 
              key={product.id}
              whileHover={{ y: -15 }}
              className="group bg-white rounded-[40px] overflow-hidden border border-gray-100 hover:border-orange-200 transition-all shadow-xl hover:shadow-2xl"
            >
              <div className={`${(product.id === 'wipes' || product.id === 'spray' || product.id === 'bodywash') ? 'aspect-auto' : 'aspect-[1/1.2]'} overflow-hidden relative bg-white`}>
                <img 
                  src={product.image} 
                  alt={product.content.name[lang]} 
                  className={`w-full ${(product.id === 'wipes' || product.id === 'spray' || product.id === 'bodywash') ? 'h-auto cursor-default pointer-events-none' : 'h-full object-cover group-hover:scale-105 transition-transform duration-1000'}`}
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-6 left-6 flex flex-col gap-2">
                  <div className="bg-white/90 backdrop-blur text-[#db7536] text-[10px] font-bold px-4 py-1.5 rounded-full uppercase tracking-widest shadow-sm">
                    {(t as any).tag[lang]}
                  </div>
                  {product.badge && (
                    <div className="bg-[#db7536] text-white text-[10px] font-bold px-4 py-1.5 rounded-full uppercase tracking-widest shadow-sm">
                      {product.badge[lang]}
                    </div>
                  )}
                </div>
              </div>
              <div className="p-10">
                <div className="flex items-center gap-2 text-gray-400 mb-6">
                  {product.icon}
                  <span className="text-[10px] font-bold uppercase tracking-widest">Premium Quality</span>
                </div>
                <h4 className="text-2xl font-bold mb-4">{product.content.name[lang]}</h4>
                <p className="text-gray-500 text-base leading-relaxed line-clamp-3 mb-8">
                  {product.content.desc[lang]}
                </p>

                {product.id === 'wipes' && (
                  <a 
                    href="#resources"
                    className="flex items-center justify-center gap-2 w-full py-4 bg-[#db7536] text-white rounded-2xl text-sm font-bold hover:bg-[#c6652e] transition-all transform group/btn active:scale-95 shadow-lg shadow-orange-100"
                  >
                    <Info size={18} className="group-hover/btn:scale-110 transition-transform" />
                    {lang === 'EN' ? 'Download Product Catalog' : '製品カタログをダウンロード'}
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
