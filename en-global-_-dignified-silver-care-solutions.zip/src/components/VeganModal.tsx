
import { motion, AnimatePresence } from 'motion/react';
import { X, Download, ShieldCheck } from 'lucide-react';
import { useEffect } from 'react';

interface VeganModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VeganModal = ({ isOpen, onClose }: VeganModalProps) => {
  const fileId = '1nOFeBdmb9zE0QFJzrq2-eoneqKcy8wrs';
  const previewUrl = `https://drive.google.com/file/d/${fileId}/preview`;
  const downloadUrl = `https://drive.google.com/uc?export=download&id=${fileId}`;

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 30 }}
            className="relative bg-white rounded-[32px] shadow-2xl max-w-5xl w-full max-h-[95vh] overflow-y-auto z-20 flex flex-col"
          >
            {/* Header */}
            <div className="p-8 border-b border-gray-100 flex items-start justify-between bg-gray-50/50 sticky top-0 z-30">
              <div>
                <div className="flex items-center gap-2 text-green-600 font-bold text-xs uppercase tracking-widest mb-3">
                  <ShieldCheck size={14} /> Certified Excellence
                </div>
                <h2 className="text-3xl font-bold text-[#333]">KOREA VEGAN CERTIFICATE</h2>
              </div>
              <div className="flex items-center gap-4">
                <a
                  href={downloadUrl}
                  className="hidden sm:flex items-center gap-2 px-4 py-2 bg-[#db7536] text-white rounded-xl text-sm font-bold hover:bg-[#c6652e] transition-all"
                >
                  <Download size={18} /> Download PDF
                </a>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-white rounded-full text-gray-400 hover:text-[#db7536] transition-all shadow-sm border border-gray-100"
                >
                  <X size={24} />
                </button>
              </div>
            </div>

            {/* Content Area (Iframe for PDF) */}
            <div className="flex-1 bg-gray-100 relative">
              <iframe
                src={previewUrl}
                className="w-full h-[850px] border-none"
                allow="autoplay"
              ></iframe>
            </div>

            {/* Mobile Download Button */}
            <div className="sm:hidden p-4 bg-white border-t border-gray-100">
              <a
                href={downloadUrl}
                className="w-full flex items-center justify-center gap-2 py-4 bg-[#db7536] text-white rounded-2xl font-bold"
              >
                <Download size={20} /> Download PDF
              </a>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
