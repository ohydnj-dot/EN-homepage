
import { motion } from 'motion/react';
import { useState } from 'react';
import { Language, translations } from '../translations';
import { CheckCircle2, Award, Users, Search, ExternalLink, ClipboardList, ShieldCheck, FileText } from 'lucide-react';
import { PatentModal } from './PatentModal';
import { SupplyModal } from './SupplyModal';
import { VeganModal } from './VeganModal';
import { IngredientsModal } from './IngredientsModal';

export const Proof = ({ lang }: { lang: Language }) => {
  const [isPatentModalOpen, setIsPatentModalOpen] = useState(false);
  const [isSupplyModalOpen, setIsSupplyModalOpen] = useState(false);
  const [isVeganModalOpen, setIsVeganModalOpen] = useState(false);
  const [isIngredientsModalOpen, setIsIngredientsModalOpen] = useState(false);
  const t = translations.proof;

  return (
    <section id="proof" className="py-24 bg-white border-y border-gray-100">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-[#db7536] uppercase tracking-widest mb-4">Market Validation</h2>
          <h3 className="text-4xl font-bold">{t.title[lang]}</h3>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { 
              icon: <Users />, 
              label: t.partners[lang], 
              desc: { EN: "Reliable supply chain within South Korea.", JP: "韓国国内での安定したサプライチェーン。" },
              supplyAction: true
            },
            { 
              icon: <Award />, 
              label: t.certification[lang], 
              desc: { EN: "Certified by patented R&D.", JP: "特許取得済みのR&D。" },
              hasAction: true
            },
            { 
              icon: <Search />, 
              label: { EN: "Pure & Proven Safety", JP: "純粋で証明された安全性" }, 
              desc: { EN: "Certified Vegan & Skin-Friendly Formulation.", JP: "ヴィーガン認証済みの肌に優しい処方。" },
              hasVeganAction: true,
              hasIngredientsAction: true
            },
            { icon: <CheckCircle2 />, label: { EN: "Practical Insights from a Licensed Social Worker", JP: "社会福祉士による実践的な視点" }, desc: { EN: "Designed by a Licensed Social Worker Who Understands the Field.", JP: "現場を知る社会福祉士によって設計された製品。" } },
          ].map((stat, idx) => (
            <motion.div 
              key={idx} 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="p-8 rounded-3xl bg-gray-50 border border-transparent hover:border-gray-200 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 text-[#db7536] mb-6">{stat.icon}</div>
                <h4 className="text-xl font-bold mb-3">{typeof stat.label === 'string' ? stat.label : (stat.label as any)[lang]}</h4>
                <p className="text-sm text-gray-500 leading-relaxed">{stat.desc[lang]}</p>
              </div>
              {stat.hasAction && (
                <button 
                  onClick={() => setIsPatentModalOpen(true)}
                  className="mt-6 flex items-center gap-2 text-xs font-bold text-[#db7536] hover:text-[#c6652e] transition-colors group w-fit"
                >
                  {lang === 'EN' ? 'View Patent (KR)' : 'View Patent (韓国特許)'} 
                  <ExternalLink size={14} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </button>
              )}
              {stat.hasVeganAction && (
                <button 
                  onClick={() => setIsVeganModalOpen(true)}
                  className="mt-6 flex items-center gap-2 text-xs font-bold text-green-600 hover:text-green-700 transition-colors group w-fit"
                >
                  <ShieldCheck size={14} />
                  {t.veganCert[lang]} 
                  <ExternalLink size={14} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </button>
              )}
              {stat.hasIngredientsAction && (
                <button 
                  onClick={() => setIsIngredientsModalOpen(true)}
                  className="mt-4 flex items-center gap-2 text-xs font-bold text-blue-600 hover:text-blue-700 transition-colors group w-fit"
                >
                  <FileText size={14} />
                  {t.ingredients[lang]} 
                  <ExternalLink size={14} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </button>
              )}
              {(stat as any).supplyAction && (
                <button 
                  onClick={() => setIsSupplyModalOpen(true)}
                  className="mt-6 flex items-center gap-2 text-xs font-bold text-[#db7536] hover:text-[#c6652e] transition-colors group w-fit"
                >
                  {lang === 'EN' ? 'Official Supply Record' : '公式供給実績'} 
                  <ClipboardList size={14} className="group-hover:scale-110 transition-transform" />
                </button>
              )}
            </motion.div>
          ))}
        </div>
      </div>
      <PatentModal 
        isOpen={isPatentModalOpen} 
        onClose={() => setIsPatentModalOpen(false)} 
      />
      <SupplyModal 
        isOpen={isSupplyModalOpen}
        onClose={() => setIsSupplyModalOpen(false)}
        lang={lang}
      />
      <VeganModal 
        isOpen={isVeganModalOpen}
        onClose={() => setIsVeganModalOpen(false)}
      />
      <IngredientsModal 
        isOpen={isIngredientsModalOpen}
        onClose={() => setIsIngredientsModalOpen(false)}
      />
    </section>
  );
};
