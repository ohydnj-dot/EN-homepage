
import { Language, translations } from '../translations';
import { Globe, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface HeaderProps {
  lang: Language;
  setLang: (lang: Language) => void;
}

export const Header = ({ lang, setLang }: HeaderProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const t = translations.header;

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-[#db7536] rounded-full flex items-center justify-center">
            <span className="text-white font-bold text-xl">EN</span>
          </div>
          <span className="font-bold text-xl tracking-tight hidden sm:block">Environment & Neighbor</span>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <a href="#products" className="text-sm font-medium hover:text-[#db7536] transition-colors">{t.products[lang]}</a>
          <a href="#solution" className="text-sm font-medium hover:text-[#db7536] transition-colors">{t.solution[lang]}</a>
          <a href="#expertise" className="text-sm font-medium hover:text-[#db7536] transition-colors">{(t as any).expertise[lang]}</a>
          <a href="#proof" className="text-sm font-medium hover:text-[#db7536] transition-colors">{t.proof[lang]}</a>
          <a href="#contact" className="px-5 py-2 bg-[#db7536] text-white rounded-full text-sm font-medium hover:bg-[#c6652e] transition-colors">
            {t.contact[lang]}
          </a>
          
          <div className="flex items-center gap-1 border-l pl-8 border-gray-200">
            <button 
              onClick={() => setLang('EN')}
              className={`text-xs font-bold px-2 py-1 transition-colors ${lang === 'EN' ? 'text-[#db7536]' : 'text-gray-400 hover:text-gray-600'}`}
            >
              EN
            </button>
            <span className="text-gray-300 text-xs">|</span>
            <button 
              onClick={() => setLang('JP')}
              className={`text-xs font-bold px-2 py-1 transition-colors ${lang === 'JP' ? 'text-[#db7536]' : 'text-gray-400 hover:text-gray-600'}`}
            >
              JP
            </button>
          </div>
        </nav>

        {/* Mobile Toggle */}
        <button className="md:hidden p-2" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white absolute top-20 left-0 w-full border-b border-gray-100 p-6 flex flex-col gap-6 animate-in slide-in-from-top duration-300">
          <a href="#products" onClick={() => setIsOpen(false)} className="text-lg font-medium">{t.products[lang]}</a>
          <a href="#solution" onClick={() => setIsOpen(false)} className="text-lg font-medium">{t.solution[lang]}</a>
          <a href="#expertise" onClick={() => setIsOpen(false)} className="text-lg font-medium">{(t as any).expertise[lang]}</a>
          <a href="#proof" onClick={() => setIsOpen(false)} className="text-lg font-medium">{t.proof[lang]}</a>
          <a href="#contact" onClick={() => setIsOpen(false)} className="text-lg font-medium text-[#db7536]">{t.contact[lang]}</a>
          <div className="flex gap-4 pt-4 border-t">
             <button onClick={() => {setLang('EN'); setIsOpen(false);}} className={lang === 'EN' ? 'font-bold text-[#db7536]' : ''}>English</button>
             <button onClick={() => {setLang('JP'); setIsOpen(false);}} className={lang === 'JP' ? 'font-bold text-[#db7536]' : ''}>日本語</button>
          </div>
        </div>
      )}
    </header>
  );
};
