
import { Language, translations } from '../translations';

export const Footer = ({ lang }: { lang: Language }) => {
  const t = translations.footer;

  return (
    <footer className="py-12 border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#db7536] rounded-full flex items-center justify-center text-white font-bold text-xs">EN</div>
          <p className="text-sm font-bold tracking-tight">Environment & Neighbor</p>
        </div>
        
        <div className="flex flex-col items-center md:items-end">
          <p className="text-xs text-gray-400 mb-2">{t.rights[lang]}</p>
          <p className="text-[10px] text-gray-300 italic">{t.disclaimer[lang]}</p>
        </div>
      </div>
    </footer>
  );
};
