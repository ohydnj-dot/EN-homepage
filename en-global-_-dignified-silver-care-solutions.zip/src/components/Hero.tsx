
import { motion } from 'motion/react';
import { Language, translations } from '../translations';
import { ChevronRight } from 'lucide-react';

export const Hero = ({ lang }: { lang: Language }) => {
  const t = translations.hero;

  return (
    <section id="home" className="relative pt-32 pb-12 md:pt-48 md:pb-16 min-h-[85vh] flex flex-col justify-center overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center mb-12">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <span className="inline-block px-4 py-1.5 border border-[#db7536] text-[#db7536] text-xs font-bold tracking-widest uppercase rounded-full mb-6">
            Expert Led Innovation
          </span>
          <h1 className="text-5xl md:text-7xl font-bold leading-[1.1] mb-8">
            {t.slogan[lang]}
          </h1>
          <p className="text-lg text-gray-500 mb-10 max-w-lg leading-relaxed">
            {t.description[lang]}
          </p>
          <div className="flex flex-wrap gap-4">
            <a href="#products" className="px-8 py-4 bg-[#db7536] text-white rounded-full font-bold flex items-center gap-2 hover:bg-[#c6652e] transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-orange-100">
              {t.ctaProducts[lang]} <ChevronRight size={18} />
            </a>
            <a href="#solution" className="px-8 py-4 bg-white border border-gray-200 text-gray-700 rounded-full font-bold flex items-center gap-2 hover:border-[#db7536] hover:text-[#db7536] transition-all transform hover:scale-105 active:scale-95">
              {t.ctaNonenal[lang]}
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="rounded-[40px] overflow-hidden shadow-2xl relative z-10 bg-white">
            <img 
              src="https://www.enbcs.kr/theme/enbcs/img/business/new_eq_6.jpg" 
              alt="EN Company Facility"
              className="w-full h-auto cursor-default pointer-events-none"
              referrerPolicy="no-referrer"
            />
            {/* Overlay tag for "Body odor associated with aging" in JP */}
            {lang === 'JP' && (
              <div className="absolute inset-0 bg-black/5 flex items-end p-8">
                <span className="bg-white/95 backdrop-blur px-5 py-2.5 rounded-2xl text-xs font-black shadow-xl tracking-tighter border border-orange-50">
                   加齢臭(かれいしゅう) 対策専門
                </span>
              </div>
            )}
          </div>
          <div className="absolute -top-12 -right-12 w-64 h-64 bg-orange-100/50 rounded-full -z-10 blur-[100px] opacity-40 animate-pulse"></div>
          <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-gray-50 rounded-full -z-10 blur-3xl opacity-60 animate-pulse delay-1000"></div>
        </motion.div>
      </div>
    </section>
  );
};
