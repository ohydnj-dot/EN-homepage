
import React, { useState } from 'react';
import { Language, translations } from '../translations';
import { Send, MapPin, Mail, Phone, CheckCircle } from 'lucide-react';

export const Contact = ({ lang }: { lang: Language }) => {
  const t = translations.contact;
  const [state, setState] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setState('submitting');
    
    const form = e.currentTarget;
    const data = new FormData(form);
    
    try {
      const response = await fetch(form.action, {
        method: form.method,
        body: data,
        headers: {
          'Accept': 'application/json'
        }
      });
      
      if (response.ok) {
        setState('success');
        form.reset();
      } else {
        setState('idle');
        alert('Something went wrong. Please try again.');
      }
    } catch (error) {
      setState('idle');
      alert('Something went wrong. Please try again.');
    }
  };

  return (
    <section id="contact" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="bg-[#333] rounded-[40px] overflow-hidden flex flex-col lg:flex-row">
          <div className="p-12 lg:p-16 flex-1 text-white">
            <h2 className="text-sm font-bold text-[#db7536] uppercase tracking-widest mb-4">Get in Touch</h2>
            <h3 className="text-4xl font-bold mb-8">{t.title[lang]}</h3>
            
            {state === 'success' ? (
              <div className="bg-white/5 border border-[#db7536]/30 p-8 rounded-[30px] flex flex-col items-center text-center animate-in fade-in zoom-in duration-500">
                <div className="w-16 h-16 bg-[#db7536] rounded-full flex items-center justify-center mb-6 shadow-lg shadow-[#db7536]/20">
                  <CheckCircle size={32} className="text-white" />
                </div>
                <p className="text-xl font-bold mb-2">Thank You!</p>
                <p className="text-gray-400">Your inquiry has been received. Our sales team will get back to you within 24 hours.</p>
                <button 
                  onClick={() => setState('idle')}
                  className="mt-8 text-sm font-bold text-[#db7536] hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form 
                action="https://formspree.io/f/xojrkyvy" 
                method="POST" 
                className="space-y-6" 
                onSubmit={handleSubmit}
              >
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">{t.name[lang]}</label>
                    <input 
                      name="name"
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#db7536] transition-colors" 
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">{t.region[lang]}</label>
                    <input 
                      name="region"
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#db7536] transition-colors" 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">{t.email[lang]}</label>
                  <input 
                    name="email"
                    type="email" 
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#db7536] transition-colors" 
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">{t.message[lang]}</label>
                  <textarea 
                    name="message"
                    required
                    rows={4} 
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#db7536] transition-colors resize-none"
                  ></textarea>
                </div>
                <button 
                  disabled={state === 'submitting'}
                  className="w-full py-5 bg-[#db7536] text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-[#c6652e] transition-all transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:grayscale"
                >
                  {state === 'submitting' ? 'Sending...' : t.submit[lang]} <Send size={18} />
                </button>
              </form>
            )}
          </div>

          <div className="bg-[#2a2a2a] p-12 lg:p-16 lg:w-1/3 text-white border-l border-white/5">
             <h4 className="font-bold text-xl mb-10">{lang === 'EN' ? 'Global HQ' : 'グローバル本社'}</h4>
             <div className="space-y-10">
               <div className="flex gap-6">
                 <div className="w-10 h-10 flex-shrink-0 bg-white/5 rounded-xl flex items-center justify-center text-[#db7536]">
                   <MapPin size={20} />
                 </div>
                 <div>
                   <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Address</p>
                   <p className="text-sm">Rm 314-315, Hanyang Univ. ERICA BI, 55 Hanyangdaehak-ro, Ansan, Korea</p>
                 </div>
               </div>
               <div className="flex gap-6">
                 <div className="w-10 h-10 flex-shrink-0 bg-white/5 rounded-xl flex items-center justify-center text-[#db7536]">
                   <Mail size={20} />
                 </div>
                 <div>
                   <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Inquiry</p>
                   <p className="text-sm">sales@en-derm.kr</p>
                 </div>
               </div>
               <div className="flex gap-6">
                 <div className="w-10 h-10 flex-shrink-0 bg-white/5 rounded-xl flex items-center justify-center text-[#db7536]">
                   <Phone size={20} />
                 </div>
                 <div>
                   <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Direct</p>
                   <p className="text-sm">+82 10-2316-4521</p>
                 </div>
               </div>
             </div>

             <div className="mt-16 pt-16 border-t border-white/5">
                <p className="text-xs text-gray-500 leading-relaxed italic">
                   {lang === 'EN' 
                     ? 'Partnering with global distribution networks to bring dignity to senior life.'
                     : 'シニアライフに尊厳をもたらすため、グローバルな流通ネットワークと提携しています。'}
                </p>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};
