
import { motion, AnimatePresence } from 'motion/react';
import React, { useState, useRef } from 'react';
import { Language, translations } from '../translations';
import { Globe, Heart, FlaskConical, ShieldCheck, X, ChevronLeft, ChevronRight, ExternalLink, MapPin, Award } from 'lucide-react';

const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-white rounded-[40px] shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto z-10 p-8 md:p-12"
          >
            <div className="flex justify-between items-center mb-8">
              <h4 className="text-2xl font-bold text-gray-900">{title}</h4>
              <button
                onClick={onClose}
                className="p-3 bg-gray-100 hover:bg-orange-100 text-gray-500 hover:text-[#db7536] rounded-full transition-all active:scale-90"
              >
                <X size={24} />
              </button>
            </div>
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const SimpleCarousel = ({ items, textPosition = 'bottom' }: { items: { img: string, text: string }[], textPosition?: 'top' | 'bottom' }) => {
  const [index, setIndex] = useState(0);
  const next = () => setIndex((prev) => (prev + 1) % items.length);
  const prev = () => setIndex((prev) => (prev - 1 + items.length) % items.length);

  return (
    <div className="relative group">
      {textPosition === 'top' && (
        <div className="mb-8 text-center px-4">
          <p className="text-gray-900 font-medium text-lg leading-relaxed">{items[index].text}</p>
        </div>
      )}
      <div className="overflow-hidden rounded-3xl aspect-[3/4] md:aspect-video bg-gray-100 shadow-inner">
        <AnimatePresence mode="wait">
          <motion.img
            key={index}
            src={items[index].img}
            alt="Gallery"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="w-full h-full object-contain pointer-events-none select-none cursor-default"
            referrerPolicy="no-referrer"
          />
        </AnimatePresence>
      </div>
      {textPosition === 'bottom' && (
        <div className="mt-6 text-center">
          <p className="text-gray-600 font-medium">{items[index].text}</p>
        </div>
      )}
      <button onClick={prev} className="absolute left-4 top-1/2 -translate-y-1/2 p-4 bg-white/95 rounded-full shadow-xl opacity-0 group-hover:opacity-100 transition-all hover:bg-[#db7536] hover:text-white border border-gray-100 z-20"><ChevronLeft size={24} /></button>
      <button onClick={next} className="absolute right-4 top-1/2 -translate-y-1/2 p-4 bg-white/95 rounded-full shadow-xl opacity-0 group-hover:opacity-100 transition-all hover:bg-[#db7536] hover:text-white border border-gray-100 z-20"><ChevronRight size={24} /></button>
      <div className="flex justify-center gap-2 mt-8">
        {items.map((_, i) => (
          <button 
            key={i} 
            onClick={() => setIndex(i)}
            className={`h-1.5 rounded-full transition-all ${index === i ? 'w-8 bg-[#db7536]' : 'w-2 bg-gray-200 hover:bg-gray-300'}`} 
          />
        ))}
      </div>
    </div>
  );
};

export const Credentials = ({ lang }: { lang: Language }) => {
  const t = translations.story as any;
  const [modalType, setModalType] = useState<'none' | 'compassion' | 'partnership' | 'safety'>('none');

  const factoryPhotos = [
    { 
      img: 'https://www.enbcs.kr/theme/enbcs/img/business/ts2.jpg', 
      text: lang === 'EN' ? 'Folding Machine: Fabric folding, filling, and cutting' : '折り機: 原反折、充填、裁断' 
    },
    { 
      img: 'https://www.enbcs.kr/theme/enbcs/img/business/ts3.jpg', 
      text: lang === 'EN' ? 'Packaging Machine: Primary packaging – punching, labeling, and sealing' : '包装機： 1次包装（パンチング、ラベル貼り、シール包装など）' 
    },
    { 
      img: 'https://www.enbcs.kr/theme/enbcs/img/business/ts4.jpg', 
      text: lang === 'EN' ? 'Cap Machine & Vision System: Cap labeling, cap attachment, and vision-based defect inspection/rejection' : 'キャップマシン／ビジョン検品： キャップラベル貼付、キャップ装着、不良品検収（ビジョン検品）およびリジェクト' 
    },
    { 
      img: 'https://www.enbcs.kr/theme/enbcs/img/business/ts5.jpg', 
      text: lang === 'EN' ? 'In-casing Machine: Automatic boxing and secondary packaging' : 'インケーサー（函詰め機）： ボックスへの自動投入および梱包' 
    },
    { 
      img: 'https://www.enbcs.kr/theme/enbcs/img/business/ts6.jpg', 
      text: lang === 'EN' ? 'Palletizer: Automatic box stacking and palletizing' : 'パレタイザー： ボックスの自動積載' 
    },
    { 
      img: 'https://www.enbcs.kr/theme/enbcs/img/business/ts1.jpg', 
      text: lang === 'EN' ? 'Manufacturing Plant (Production Line)' : '生産ライン（製造現場）' 
    },
  ];

  return (
    <section id="expertise" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20 items-center mb-16">
          {/* Founders Photo */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-orange-100/50 rounded-[48px] -rotate-3" />
            <img 
              src="https://postfiles.pstatic.net/MjAyNjA1MTBfMjgx/MDAxNzc4NDIzOTc2MTE2.1uXxmpuBRTBgv1_TGkNZFNe0GVPzqXYFgTJGX-8Ozvwg.CaCX-JZI0VjtEIo9GzuUOgDljT6wQX5zoxz9B7ZmPQsg.PNG/temp_1778422727631.-697186235.png?type=w966" 
              alt="EN Specialized Care Solution"
              className="relative w-full h-auto object-contain rounded-[40px] shadow-2xl z-10 cursor-default pointer-events-none"
              referrerPolicy="no-referrer"
            />
          </motion.div>

          {/* Mission Statement */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
          >
            <h2 className="text-sm font-bold text-[#db7536] uppercase tracking-[0.4em] mb-6">{t.title[lang]}</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-gray-900 leading-[1.2] mb-8">
              {t.mission[lang]}
            </h3>
            
            {/* Action Grid Desktop */}
            <div className="hidden md:grid grid-cols-2 gap-6">
              <a 
                href="https://aisi.or.kr/" 
                target="_blank" 
                rel="noreferrer"
                className="p-6 bg-gray-50 rounded-[32px] flex flex-col gap-4 border border-transparent hover:border-[#db7536]/30 hover:bg-orange-50/50 transition-all group relative overflow-hidden"
              >
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#db7536] shadow-sm group-hover:scale-110 transition-transform"><Globe size={24} /></div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-gray-900">{t.buttons.leadership[lang]}</span>
                  <ExternalLink size={16} className="text-gray-400 group-hover:text-[#db7536]" />
                </div>
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-[10px] font-bold text-[#db7536] uppercase tracking-tighter bg-white px-2 py-0.5 rounded-full shadow-sm">Official Site</span>
                </div>
              </a>

              <button 
                onClick={() => setModalType('compassion')} 
                className="p-6 bg-gray-50 rounded-[32px] text-left border border-transparent hover:border-[#db7536]/30 hover:bg-orange-50/50 transition-all group relative overflow-hidden active:scale-[0.98]"
              >
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#db7536] shadow-sm mb-4 group-hover:scale-110 transition-transform"><Heart size={24} /></div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-gray-900">{t.buttons.compassion[lang]}</span>
                  <div className="w-6 h-6 rounded-full bg-white border border-gray-200 flex items-center justify-center text-gray-400 group-hover:bg-[#db7536] group-hover:text-white group-hover:border-[#db7536] transition-all">
                    <ChevronRight size={14} />
                  </div>
                </div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-2 block opacity-0 group-hover:opacity-100 transition-all transform translate-y-1 group-hover:translate-y-0">
                  {lang === 'EN' ? 'View Social Impact' : '活動内容を見る'}
                </span>
              </button>

              <button 
                onClick={() => setModalType('partnership')} 
                className="p-6 bg-gray-50 rounded-[32px] text-left border border-transparent hover:border-[#db7536]/30 hover:bg-orange-50/50 transition-all group relative overflow-hidden active:scale-[0.98]"
              >
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#db7536] shadow-sm mb-4 group-hover:scale-110 transition-transform"><FlaskConical size={24} /></div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-gray-900">{t.buttons.partnership[lang]}</span>
                  <div className="w-6 h-6 rounded-full bg-white border border-gray-200 flex items-center justify-center text-gray-400 group-hover:bg-[#db7536] group-hover:text-white group-hover:border-[#db7536] transition-all">
                    <ChevronRight size={14} />
                  </div>
                </div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-2 block opacity-0 group-hover:opacity-100 transition-all transform translate-y-1 group-hover:translate-y-0">
                  {lang === 'EN' ? 'Hanyang Univ. R&D' : '漢陽大学 産学協力'}
                </span>
              </button>

              <button 
                onClick={() => setModalType('safety')} 
                className="p-6 bg-gray-50 rounded-[32px] text-left border border-transparent hover:border-[#db7536]/30 hover:bg-orange-50/50 transition-all group relative overflow-hidden active:scale-[0.98]"
              >
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#db7536] shadow-sm mb-4 group-hover:scale-110 transition-transform"><ShieldCheck size={24} /></div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-gray-900">{t.buttons.safety[lang]}</span>
                  <div className="w-6 h-6 rounded-full bg-white border border-gray-200 flex items-center justify-center text-gray-400 group-hover:bg-[#db7536] group-hover:text-white group-hover:border-[#db7536] transition-all">
                    <ChevronRight size={14} />
                  </div>
                </div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-2 block opacity-0 group-hover:opacity-100 transition-all transform translate-y-1 group-hover:translate-y-0">
                  {lang === 'EN' ? 'Factory & Certification' : '工場と認証'}
                </span>
              </button>
            </div>
          </motion.div>
        </div>

        {/* Mobile Buttons */}
        <div className="md:hidden grid grid-cols-1 gap-4">
           <a href="https://aisi.or.kr/" target="_blank" rel="noreferrer" className="flex items-center justify-between p-5 bg-gray-50 rounded-[24px] border border-gray-100 active:bg-orange-50">
             <div className="flex items-center gap-4">
               <Globe className="text-[#db7536]" /> 
               <span className="font-bold">{t.buttons.leadership[lang]}</span>
             </div>
             <ExternalLink size={16} className="text-gray-400" />
           </a>
           <button onClick={() => setModalType('compassion')} className="flex items-center justify-between p-5 bg-gray-50 rounded-[24px] border border-gray-100 text-left active:bg-orange-50">
             <div className="flex items-center gap-4">
               <Heart className="text-[#db7536]" /> 
               <span className="font-bold">{t.buttons.compassion[lang]}</span>
             </div>
             <ChevronRight size={18} className="text-[#db7536]" />
           </button>
           <button onClick={() => setModalType('partnership')} className="flex items-center justify-between p-5 bg-gray-50 rounded-[24px] border border-gray-100 text-left active:bg-orange-50">
             <div className="flex items-center gap-4">
               <FlaskConical className="text-[#db7536]" /> 
               <span className="font-bold">{t.buttons.partnership[lang]}</span>
             </div>
             <ChevronRight size={18} className="text-[#db7536]" />
           </button>
           <button onClick={() => setModalType('safety')} className="flex items-center justify-between p-5 bg-gray-50 rounded-[24px] border border-gray-100 text-left active:bg-orange-50">
             <div className="flex items-center gap-4">
               <ShieldCheck className="text-[#db7536]" /> 
               <span className="font-bold">{t.buttons.safety[lang]}</span>
             </div>
             <ChevronRight size={18} className="text-[#db7536]" />
           </button>
        </div>
      </div>

      {/* Modals */}
      <Modal isOpen={modalType === 'compassion'} onClose={() => setModalType('none')} title={t.buttons.compassion[lang]}>
        <SimpleCarousel 
          textPosition="top"
          items={t.compassionModal.map((m: any) => ({ img: m.img, text: m.caption[lang] }))} 
        />
      </Modal>

      <Modal isOpen={modalType === 'partnership'} onClose={() => setModalType('none')} title={t.buttons.partnership[lang]}>
        <div className="space-y-8">
          <div className="bg-gray-50 p-6 md:p-10 rounded-[32px] flex flex-col gap-8">
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-[#db7536] shadow-md shrink-0 border border-orange-50">
                <MapPin size={32} />
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className="bg-gray-900 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter flex items-center gap-1.5 shadow-sm">
                    <Award size={10} className="text-[#db7536]" />
                    Global Headquarters
                  </span>
                  <span className="bg-orange-100 text-[#db7536] text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter">
                    R&D Partnership
                  </span>
                  <span className="bg-white text-gray-500 text-[10px] font-bold px-3 py-1 rounded-full border border-gray-200">
                    Venture Incubation Center
                  </span>
                </div>
                <h5 className="font-extrabold text-3xl md:text-4xl mb-4 text-gray-900 tracking-tight leading-tight">
                  {t.partnership.university[lang]}
                </h5>
                <p className="text-gray-500 text-sm mb-6 leading-relaxed bg-white p-5 rounded-2xl border-2 border-orange-50 shadow-sm font-medium">
                  {t.partnership.address[lang]}
                </p>
                <div className="w-full h-80 rounded-3xl overflow-hidden border-4 border-white shadow-2xl relative">
                  <div className="absolute top-4 left-4 z-10">
                    <div className="bg-white/90 backdrop-blur px-4 py-2 rounded-xl shadow-sm border border-gray-100 flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                      <span className="text-[10px] font-bold text-gray-800 uppercase tracking-widest">Live Campus Map</span>
                    </div>
                  </div>
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1587.2183!2d126.8368!3d37.3005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x357b6f68c7e9f3b5%3A0xe1c0c80b5ed3a465!2z7ZWc7JaR64yA7ZWZ6rWQIEVSSUNB7LqY7Y287IqkIOywvemodulerOqyqOq0gA!5e0!3m2!1sko!2skr!4v1715320000000!5m2!1sko!2skr"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Google Maps Location"
                  ></iframe>
                </div>
              </div>
            </div>
            <div className="flex justify-center md:justify-start md:ml-28">
              <a 
                href="https://maps.app.goo.gl/Muvb2EG9k6ZCNUHc9" 
                target="_blank" 
                rel="noreferrer"
                className="inline-flex items-center gap-3 text-white font-bold text-sm bg-gray-900 px-8 py-4 rounded-2xl hover:bg-black transition-all shadow-lg active:scale-95"
              >
                Get Directions <ExternalLink size={18} />
              </a>
            </div>
          </div>
          <div className="border-t pt-8">
            <div className="flex items-center gap-3 text-[#db7536] mb-6">
              <Award size={20} />
              <span className="font-bold uppercase tracking-widest text-xs">{t.partnership.professor[lang]}</span>
            </div>
            
            <div className="flex flex-col items-center gap-8">
              <div className="max-w-[600px] w-full aspect-[600/848] rounded-[40px] overflow-hidden shadow-2xl border border-gray-100 bg-white">
                <img 
                  src="https://postfiles.pstatic.net/MjAyNjA1MTFfMjg1/MDAxNzc4NDMwODU5NzY2.2vlSP0gZtojLLOoGGon4fHn1vInnKDhlQlF5_5ZlpUkg.YfDNxS-56V5ldAD4FDhuK6uZ04SbDvkAVMVGthrtL1sg.PNG/Gemini_Generated_Image_sqsy67sqsy67sqsy.png?type=w966" 
                  alt="R&D Partnership Photo"
                  className="w-full h-full object-cover cursor-default pointer-events-none select-none"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="bg-gray-900 text-white rounded-[40px] p-10 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#db7536]/10 rounded-full -mr-16 -mt-16 blur-3xl" />
                <div className="relative z-10">
                  <h6 className="text-2xl font-bold mb-6 tracking-tight">{t.partnership.patent[lang]}</h6>
                  <div className="w-16 h-1.5 bg-[#db7536] rounded-full mb-8" />
                  <p className="text-base md:text-lg opacity-90 leading-relaxed font-medium">
                    {lang === 'EN' 
                      ? 'Exclusive transfer of biological formula specialized in 2-Nonenal molecule neutralization based on botanical extracts research.' 
                      : 'ボタニカルエキス研究に基づいた2-ノネナール分子中和に特化したバイオ処方の独占移転。'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal>

      <Modal isOpen={modalType === 'safety'} onClose={() => setModalType('none')} title={t.buttons.safety[lang]}>
        <div className="space-y-10">
          <SimpleCarousel items={factoryPhotos} />

          <div className="grid sm:grid-cols-2 gap-6 pt-4">
            <div className="bg-orange-50 p-6 rounded-3xl">
              <ShieldCheck className="text-[#db7536] mb-3" />
              <h5 className="font-bold mb-2">{t.safety.principles[lang]}</h5>
              <p className="text-xs text-gray-500 leading-relaxed">
                {lang === 'EN' 
                  ? 'We use pharmaceutical-grade water purified through 12 rigorous filtration steps to ensure zero irritability.' 
                  : '12段階の厳格なろ過工程を経た医薬品グレードの精製水を使用し、刺激ゼロを保証します。'}
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-3xl">
              <Award className="text-[#db7536] mb-3" />
              <h5 className="font-bold mb-2">{t.safety.certification[lang]}</h5>
              <p className="text-xs text-gray-500 leading-relaxed">
                {lang === 'EN' 
                  ? 'Certified by global safety standards, ensuring the highest purity in every batch produced.' 
                  : 'グローバルな安全基準によって認証されており、製造されるすべてのバッチにおいて最高水準の純度を保証します。'}
              </p>
            </div>
          </div>
        </div>
      </Modal>
    </section>
  );
};

