export type Language = 'EN' | 'JP';

export const translations = {
  header: {
    products: { EN: 'Products', JP: '製品情報' },
    solution: { EN: 'Solution', JP: 'ソリューション' },
    expertise: { EN: 'About Us', JP: '会社紹介' },
    proof: { EN: 'Proof', JP: '実績' },
    contact: { EN: 'Contact', JP: 'お問い合わせ' },
  },
  hero: {
    slogan: { 
      EN: 'The Solution for Elderly Body Odor', 
      JP: '加齢臭の悩みを解決する専門ソリューション' 
    },
    description: { 
      EN: 'We neutralize Nonenal the root cause of aging smells through expert innovation',
      JP: '加齢臭の原因物質であるノネナールを独自の技術で中和・除去します'
    },
    ctaProducts: { EN: 'Our Products', JP: '製品一覧' },
    ctaNonenal: { EN: 'What is Nonenal', JP: 'ノネナールとは？' },
  },
  story: {
    title: { EN: 'About Us', JP: '会社紹介' },
    mission: { 
      EN: 'Expert Hygiene Solutions for the Golden Years.',
      JP: '科学的なイノベーションと慈愛に満ちたケアを通じて、すべての高齢者の尊厳を取り戻します。'
    },
    buttons: {
      leadership: { EN: 'Global Leadership', JP: 'グローバルリーダーシップ' },
      compassion: { EN: 'Compassion', JP: '慈愛' },
      partnership: { EN: 'R&D Partnership', JP: '産学連携' },
      safety: { EN: 'Safety & Purity', JP: '安全と純度' }
    },
    compassionModal: [
      { 
        img: 'https://www.enbcs.kr/data/editor/2512/thumb-2183f31b64688f4a9da513777bfc237f_1767059767_043_860x1147.jpg', 
        caption: { 
          EN: "Dec 30, 2025: Product donation to the Ansan Branch of the Korean Senior Citizens Association.", 
          JP: "2025年12月30日：大韓老人会安山支部へ製品を寄贈。" 
        } 
      },
      { 
        img: 'https://www.enbcs.kr/data/editor/2512/thumb-16cc76484c102082f1a320b044ee68e3_1766968403_2756_860x1147.jpg', 
        caption: { 
          EN: "Dec 29, 2025: CEO Guest Lecture at YUHAN UNIV. WELLNESS LIVING LAB.", 
          JP: "2025年12月29日：柳韓大学校 WELLNESS LIVING LABにてCEO特別講義を実施。" 
        } 
      },
      { 
        img: 'https://www.enbcs.kr/data/editor/2502/thumb-352f6f229bb82b73cd73d756e7f73553_1739408156_5778_860x645.jpg', 
        caption: { 
          EN: "Feb 13, 2025: Donation of sports equipment for athletes with hearing impairments.", 
          JP: "2025年2月13日：ろう者スポーツ選手への用品支援を実施。" 
        } 
      },
      { 
        img: 'https://www.enbcs.kr/data/editor/2502/thumb-352f6f229bb82b73cd73d756e7f73553_1739407791_7258_860x548.png', 
        caption: { 
          EN: "Feb 14, 2025: Donated 400 nonenal-eliminating wipes to the Yongsan Welfare Foundation.", 
          JP: "2025年2月14日：龍山福祉財団へ加齢臭除去シート400個を寄託。" 
        } 
      },
      { 
        img: 'https://www.enbcs.kr/data/file/event/thumb-2039204213_0OaWluML_5e8215e434eb6df20e676e096eb013d59137d886_860x1147.jpg', 
        caption: { 
          EN: "Jan 10, 2025: CEO elected as President of the KOREAN PARA KARATE ASSOCIATION.", 
          JP: "2025年1月10日：当社CEO、大韓障害者空手道協会会長に選出。" 
        } 
      },
      { 
        img: 'https://www.enbcs.kr/data/editor/2406/thumb-3defee0c828a6474d7a718e86e8cec20_1718929047_8141_860x1147.jpg', 
        caption: { 
          EN: "Jun 21, 2024: Employees participated in a voluntary meal delivery service for seniors in Ansan, Korea.", 
          JP: "2024年6月21日：当社役職員による安山市の高齢者向けお弁当配達ボランティアに参加。" 
        } 
      },
      { 
        img: 'https://www.enbcs.kr/data/file/event/thumb-2039204213_rJhGQVO1_1696c9e1241de05f195dadf68ad5ed1be53639cb_860x1147.jpg', 
        caption: { 
          EN: "Jun 21, 2024: Donated wipes to the Korea-Japan Living Lab Forum.", 
          JP: "2024年6月21日：韓日リビングラブフォーラムへウェットティッシュを寄贈。" 
        } 
      }
    ],
    partnership: {
      university: { EN: 'Global HQ & R&D Center (Hanyang Univ. ERICA)', JP: 'グローバル本社 ＆ 産学R&Dセンター (漢陽大学校 ERICA)' },
      address: { EN: 'Corporate Headquarters: Business Incubation Center, 55 Hanyangdaehak-ro, Sangnok-gu, Ansan-si, Gyeonggi-do', JP: '本社所在地：京畿道安山市常緑区漢陽大学路55 創業・ベンチャー館' },
      professor: { EN: 'Strategic R&D Partnership with Prof. Chul-Young Kim, College of Pharmacy', JP: '薬学部 キム・チョルヨン教授との戦略的産学共同研究開発' },
      patent: { EN: 'Exclusive Patent Transfer for Nonenal Neutralization', JP: 'ノ네ナール中和技術に関する独占的な特許移転' }
    },
    safety: {
      principles: { EN: '12-Step Purified Water & Zero Harmful Substances', JP: '12段階精製水使用 ＆ 有害物質ゼロ' },
      certification: { EN: 'Globally Certified for Safe & Pure Manufacturing', JP: '安全で純粋な製造に関するグローバル認証' },
      facility: { 
        EN: 'Automated manufacturing facility complying with strict hygiene standards', 
        JP: '厳格な衛生基準を遵守する自動化製造施設',
        KR: '엄격한 위생 기준을 준수하는 자동화 제조 시설'
      }
    }
  },
  values: {
    // keeping empty or minimal if still referenced anywhere
  },
  products: {
    title: { EN: 'Global Product Lineup', JP: '加齢臭対策製品ラインナップ' },
    tag: { EN: 'Nonenal Care', JP: 'ノネナール除去' },
    wipes: {
      name: { EN: 'Large Deodorizing Wipes', JP: '大判消臭ウェットティッシュ' },
      desc: { 
        EN: "The ultimate waterless shower wipe, instantly erasing nonenal aging odor for on-the-go freshness.", 
        JP: "拭くだけで加齢臭を根本除去、水なしでシャワー直後の爽快さを再現する主力製品" 
      },
      fob: { EN: 'FOB: Busan/Incheon', JP: 'FOB: 釜山/仁川' },
      moq: { EN: 'MOQ: 5,000 units', JP: 'MOQ: 5,000個' },
    },
    spray: {
      name: { EN: 'Deodorizing Mist', JP: '消臭ミスト' },
      desc: { EN: 'Multi-purpose deodorizing mist. Safe for skin, effective for living spaces.', JP: 'リネンや居住空間向けの速攻性ボタニカルスプレー。' },
      fob: { EN: '', JP: '' },
      moq: { EN: '', JP: '' },
    },
    bodywash: {
      name: { EN: 'Senior Care Body Wash', JP: 'シニアケア ボディウォッシュ' },
      desc: { EN: 'Gentle vegan formula for sensitive skin care in nursing facilities.', JP: '介護施設の敏感な肌のための優しいヴィーガン処方。' },
      fob: { EN: '', JP: '' },
      moq: { EN: '', JP: '' },
    }
  },
  proof: {
    title: { EN: 'Proven Trust', JP: '証明された信頼' },
    partners: { EN: '300+ Nursing Homes', JP: '300以上の介護施設に導入' },
    academic: { EN: 'College of Pharmacy R&D', JP: '薬学部共同研究開発' },
    certification: { EN: 'Patent Certified', JP: '特許取得済み' },
    veganCert: { EN: 'Vegan Certificate', JP: 'ヴィーガン認証書' },
    ingredients: { EN: 'Full Ingredients', JP: '全成分表示' },
    survey: { 
      EN: '98% Satisfaction in Neutralizing Aging Odor', 
      JP: '加齢臭(かれいしゅう)の中和満足度 98%' 
    }
  },
  solution: {
    title: { EN: 'The Science of Nonenal', JP: 'ノネナールの科学' },
    card1: {
      main: { EN: "Why does the scent change with age?", JP: "なぜ年齢とともに香りが変わるのか？" },
      title: { EN: "What is 'Nonenal'?", JP: "「ノネナール」とは何か？" },
      desc: { 
        EN: 'It\'s not about hygiene. The real cause is **2-Nonenal (C9H16O)**. As we age (especially after 40), fatty acids like 9-Hexadecenoic acid oxidize and decompose, creating this unique aging odor.', 
        JP: '清潔感の問題ではありません。真の原因は**2-ノネナール (C9H16O)**です。加齢（特に40代以降）に伴い、9-ヘキサデセン酸などの脂肪酸が酸化・分解され、この独特の加齢臭が発生します。' 
      }
    },
    card2: {
      main: { EN: "The Psychological Impact", JP: "心理的影響" },
      title: { EN: "More Than Just a Smell", JP: "単なる臭い以上の問題" },
      desc: { 
        EN: '**Nonenal** often leads to social withdrawal and loss of confidence among the elderly. It\'s a delicate issue that affects both personal dignity and daily social life.', 
        JP: '**ノネナール**は、高齢者の社会的な引きこもりや自信の喪失につながることがよくあります。個人の尊厳と日常生活の両方に影響を与える繊細な問題です。' 
      }
    },
    card3: {
      main: { EN: "Hard to Wash, Easy to Stay", JP: "洗いにくく、残りやすい" },
      title: { EN: "Why Ordinary Soap Isn't Enough", JP: "普通の石鹸では不十分な理由" },
      desc: { 
        EN: '**Nonenal** is an oil-based substance that sticks to the skin (especially on the back and chest). Standard soaps often fail to neutralize these stubborn molecules.', 
        JP: '**ノネナール**は、肌（特に背中や胸元）に付着する油性の物質です。普通の石鹸では、これらの頑固な分子を中和しきれないことがよくあります。' 
      }
    },
    card4: {
      main: { EN: "Patented Solution by Hanyang University", JP: "漢陽大学による特許取得済みソリューション" },
      title: { EN: "The Scientific Breakthrough", JP: "科学的ブレイクスルー" },
      desc: { 
        EN: 'Developed in collaboration with Professor Chul-Young Kim (**College of Pharmacy, Hanyang University**). We discovered that **Lycium Chinense Miller** (Go-gi-ja) and Root Bark (Ji-gol-pi) extracts have extraordinary power to neutralize **Nonenal**.', 
        JP: '漢陽大学**薬学部**のキム・チョルヨン教授との共同開発。**クコの実（Lycium Chinense Miller）**と地骨皮（ジゴルピ）のエキスが、**ノネナール**を中和する驚異的な力を持っていることを発見しました。' 
      }
    },
    card5: {
      main: { EN: "From Removal to Respect", JP: "除去から尊重へ" },
      title: { EN: "Restoring Confidence", JP: "自信の回復" },
      desc: { 
        EN: 'We don\'t just mask the smell; we eliminate the root cause. Restore the confidence and dignity of our elders with our **patented bio-hygiene technology**.', 
        JP: '単に香りでごまかすのではありません。根本原因を排除します。**特許取得済みのバイオ衛生技術**で、高齢者の自信と尊厳を取り戻しましょう。' 
      }
    }
  },
  contact: {
    title: { EN: 'Buyer Inquiry', JP: 'バイヤー専用のお問い合わせ' },
    name: { EN: 'Name', JP: 'お名前' },
    region: { EN: 'Region / Country', JP: '地域 / 国名' },
    email: { EN: 'Email Address', JP: 'メールアドレス' },
    message: { EN: 'Inquiry Details', JP: 'お問い合わせ内容' },
    submit: { EN: 'Send Inquiry', JP: 'お問い合わせ를 전송' },
  },
  resources: {
    title: { EN: 'Resources', JP: 'リソース' },
    subtitle: { EN: 'Download Product Catalog', JP: '製品カタログのダウンロード' },
    viewCatalog: { EN: 'Scroll to view catalog', JP: 'スクロールしてカタログを表示' },
    downloadBtn: { EN: 'Download PDF', JP: 'PDFをダウンロード' },
  },
  footer: {
    rights: { EN: '© 2026 Environment & Neighbor. All Rights Reserved.', JP: '© 2026 Environment & Neighbor. All Rights Reserved.' },
    disclaimer: { 
      EN: '*This product is a cosmetic, not a medical treatment.', 
      JP: '※本製品は化粧品であり、医薬品ではありません。' 
    }
  }
};
