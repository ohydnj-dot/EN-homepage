
import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { translations, Language } from './translations';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Solution } from './components/Solution';
import { Credentials } from './components/Credentials';
import { Products } from './components/Products';
import { Proof } from './components/Proof';
import { Resources } from './components/Resources';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

export default function App() {
  const [lang, setLang] = useState<Language>('EN');

  return (
    <div className="min-h-screen bg-white text-[#333333] font-sans selection:bg-[#db7536] selection:text-white">
      <Header lang={lang} setLang={setLang} />
      <main>
        <Hero lang={lang} />
        <Products lang={lang} />
        <Solution lang={lang} />
        <Credentials lang={lang} />
        <Proof lang={lang} />
        <Resources lang={lang} />
        <Contact lang={lang} />
      </main>
      <Footer lang={lang} />
    </div>
  );
}
